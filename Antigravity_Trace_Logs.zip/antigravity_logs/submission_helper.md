# Antigravity Hackathon Submission Helper 🚀
> [!IMPORTANT]
> **Submission Deadline:** Thursday, 21st May 2026 @ 12:00 PM (Local Time).
> You have exactly **20 minutes** remaining. Let's execute this swiftly and perfectly!

---

## 📂 1. Mandatory Submissions Package

### Item 1: Mobile App Link (Capacitor APK)
1. In your project directory (`service-orchestrator`), run:
   ```bash
   npm run build
   ```
2. Upload the built `dist` folder, or if you compiled the APK following the Capacitor instructions:
   - Upload the standalone `app-debug.apk` (found in `android/app/build/outputs/apk/debug/`) to Google Drive.
   - **Crucial:** Set the share link settings to **"Anyone with the link can view/download"**.

### Item 2: GitHub Repository Link
- Push your current local `service-orchestrator` directory to a public repository on GitHub.
  - Create a new public repo named `hamara-rozgar` or `service-orchestrator`.
  - Push the folder. Make sure `README.md` is at the root of your GitHub repository.

### Item 3: Demo Video (3-5 mins Script & Workflow)
*Use this exact flow to record your screen in one take (using OBS, Zoom, or Loom):*
1. **Intro (0:00 - 0:30)**: "Assalam-o-Alaikum, this is Hamara-Rozgar, a premium AI-driven marketplace orchestrator for Pakistan's informal economy built using Google Antigravity. We automate the booking lifecycle for plumbers, electricians, mechanics, and technicians in Islamabad."
2. **Offline Slang Demo (0:30 - 1:30)**:
   - Click the slang chip preset: `"meri motorcycle khrab ho gyi hai"` (Roman Urdu).
   - Show the **Antigravity Trace Console** firing immediately. Show the `IntentAgent` parsing the context to `"Mechanic"` with 85% confidence.
   - Point out the `DiscoveryAgent` calculating the Haversine distance, the `PricingAgent` producing a fair dynamic price including travel allowance, and the booking card appearing.
3. **Online LLM & Proximity Hub Demo (1:30 - 3:00)**:
   - Paste a **Gemini API Key** in the settings panel to activate the online agent.
   - Click the collapsible **Proximity Location Hub** banner at the top of the smartphone screen.
   - Toggle to **Custom Location**, type `"sector 4 airport society"` and click **Resolve**. Show the pulsing blue dot and dynamic coordinate geocoding output.
   - Type a complex Roman Urdu query in chat: `"yaar kitchen ke basin me toti leak ho rhi h paani beh rha h urgent G-11 me plumber chahiye"`.
   - Point out how the live `gemini-1.5-flash` model parses the exact service category, sector, urgency, and pricing coefficients.
4. **Dispute Resolution (3:00 - 4:00)**:
   - Click **Confirm Booking**. The simulator goes into "Provider En-Route" and "Work in Progress" tracking states.
   - Simulate a real-world dispute by clicking **Provider Cancel**.
   - Show the `DisputeAgent` instantly auto-rescheduling the customer to the next-best provider in the grid, applying a 150 PKR compensation credit, and updating the WhatsApp booking feed seamlessly!

### Item 4: Antigravity Usage Video (2-3 mins Screen Recording)
*Record a quick walk through your Antigravity IDE setup:*
- Open VS Code or cursor, show your `implementation_plan.md`, `task.md`, and `walkthrough.md` files.
- Talk about how Antigravity helped you design the architecture, write state triggers, debug the Geocoding API connection, build the 6-factor matching engine, and compile the production bundle flawlessly!

### Item 5: README / Documentation
- Your `README.md` inside `service-orchestrator/README.md` is already **100% complete and perfect**. It details the architecture, mock database, dynamic pricing structures, and Capacitor setup.

### Item 6: Antigravity Trace / Logs (Zip Folder)
- The judges require your Antigravity logs. Zip the following files located in your brain directory:
  - 📂 **Source Folder**: `/home/ammarasad2005/.gemini/antigravity/brain/6ed486f9-5b00-46c7-9082-a69d6cc819ab/`
  - 🗜️ **Files to include inside the zip**:
    1. `implementation_plan.md` (Design specifications)
    2. `task.md` (Completed task checklist)
    3. `walkthrough.md` (Technical achievements and scenarios)
    4. `.system_generated/logs/transcript.jsonl` (Complete raw Antigravity conversational session log)

---

## 📝 2. Architectural Description to Copy-Paste in Form

When the form asks for your **Solution Design / Architecture**, use this:
```text
Hamara-Rozgar (RozgarOrch) utilizes a decoupled, multi-agent orchestrator architecture coordinating 5 specialized AI sub-agents to streamline informal economy services:
1. IntentAgent: Implements a hybrid intent parsing system. Queries Google AI Studio's Gemini 1.5 Flash API for advanced semantic understanding of multilingual queries (English, Urdu, Roman Urdu slang) and maintains multi-turn location refinement context. Falls back gracefully to an offline regex-based parsing dictionary if key is missing.
2. DiscoveryAgent: Resolves custom location strings on-the-fly using the Google Geocoding API to lock coordinates. Ranks candidates using a 6-factor utility function (Haversine distance, ratings, on-time history, price sensitivity, direct sector matching, cancellation records) to balance marketplace workloads.
3. PricingAgent: Generates dynamic quotes on the fly based on base rates, travel allowances (distance-based), urgency surcharges (+30%), and loyalty discounts (-10%).
4. BookingAgent: Transcribes scheduled service events to Cloud Firestore Persistent storage with out-of-the-box local cached backup.
5. DisputeAgent: Implements self-healing capabilities. Monitors en-route cancellations, automatically finds and re-assigns the next best available provider, issues compensation vouchers, and提案s discount offsets.
```

Good luck Muhammad Ammar Asad, you are about to secure the top spot! Let's submit! 🏆
