# Implementation Plan - Startup GPS Fetch & Dynamic Location Override

An agentic AI-driven marketplace orchestrator ("Hamara-Rozgar") built using Vite, React, Vanilla CSS, and Firebase. This plan details the integration of a beautiful, premium **Proximity & Location Hub** inside the smartphone simulator to satisfy the requirement of fetching the user's current location at startup, while allowing a completely dynamic, non-pre-fetched custom address override that geocodes coordinates on the fly.

---

## User Review Required

We are designing a highly visual, interactive location system. The user will automatically see their real-time location fetched at startup, and can seamlessly type any dynamic, non-pre-fetched custom address (like `"sector 4 airport society"` or `"I-8/4"`) to geocode it live.

> [!IMPORTANT]
> **Key Architecture Decisions:**
> 1. **Startup Geolocation Acquisition**: On app load, `navigator.geolocation.getCurrentPosition` is automatically triggered, establishing the baseline latitude and longitude. The UI will show a live status indicator (pulsing green dot) showing "Live GPS Coordinates".
> 2. **Dynamic Location Override Option**: A sleek, premium drop-down banner in the smartphone simulator will allow users to toggle from `GPS` to `Custom Input`.
> 3. **Dynamic Geocoding API Execution**: When the user enters a custom location, it is **not pre-fetched** or hardcoded. The orchestrator will dynamically call the Google Geocoding API to resolve the custom address string to real coordinates on the fly.
> 4. **Smart Offline Fallback**: If no Maps API Key is entered, or if geocoding fails, the system will fall back to our local regex slang parser to extract raw locations and center them to a standard baseline, ensuring 100% offline robustness.
> 5. **Reactive Provider Grid Updates**: Distance calculations (`Haversine`) and dynamic travel pricing will instantly recalculate relative to the dynamic geocoded coordinates.

---

## Proposed Changes

### 1. Proximity Hub and UI Integration

#### [MODIFY] [App.jsx](file:///home/ammarasad2005/Desktop/AntiGravity_Hackathon/service-orchestrator/src/App.jsx)
- **Add Coordinate States**:
  - Keep `gpsCoords` for pre-fetched GPS.
  - Add `customCoords` to hold dynamically geocoded coordinate points.
  - Maintain `locationMode` (either `"GPS"` or `"Custom"`).
  - Bind `customLocationName` and `resolvedLocationName` to track custom names and user-facing status text.
- **Implement Startup GPS Logic**:
  - Automatically query browser coordinates. If successful, set `gpsCoords`, set `resolvedLocationName` to `"Live GPS Location"`, and default `locationMode` to `"GPS"`.
  - If blocked, fallback gracefully to `"G-13"` coordinate default and log reasoning in the Antigravity Trace Console.
- **Create Interactive Proximity Selector Widget**:
  - Embed a glassmorphic **Proximity Banner** directly underneath the App Header inside the phone frame simulator.
  - Display the current location mode and resolved label.
  - Add an expand/collapse toggler `"⚙️ Location Options"`.
  - When expanded, render:
    - A **GPS Tab Button** that switches back to browser coordinates and triggers a re-fetch of current coordinates.
    - A **Custom Input Option** with a beautiful input field and `"Geocode Location"` button.
    - A dynamic indicator showing resolved latitude and longitude.
- **Connect Custom Overrides on Submit**:
  - When the user sends a natural language query:
    - If `locationMode === "Custom"`, send the dynamic custom address to the parsing and geocoding engines.
    - If the user specifies a location in their chat message (e.g. `"main sector 4 airport society mein rehta hu"`), the parsing agent will extract it, and the app will automatically switch `locationMode` to `"Custom"`, set the `customLocationName`, and geocode it dynamically!
- **Recalculate Provider Metrics**:
  - Ensure `orchestrator.discoverAndRank` uses the active coordinates based on `locationMode` (`gpsCoords` or `customCoords`) to dynamically compute distance offsets.

---

### 2. Style Sheet Upgrades

#### [MODIFY] [index.css](file:///home/ammarasad2005/Desktop/AntiGravity_Hackathon/service-orchestrator/src/index.css)
- Add CSS classes for the glassmorphic proximity indicator panel, active tabs, coordinate badges, text inputs, and action buttons.
- Create subtle micro-animations (e.g., pulsing status dots for live GPS vs dynamic override modes).

---

## Verification Plan

### Automated & Manual Verification
- **Startup Fetch**: Load the page in the browser. Allow location sharing. Verify that the trace console logs: `"Successfully fetched browser Geolocation at startup to use as default proximity center"` and the simulator shows the pulsing green GPS badge.
- **Dynamic Override Test**:
  1. Click `"Location Options"` inside the simulator.
  2. Toggle to `"Custom Location"`.
  3. Type `"sector 4 airport society"` (or any address) and click `"Geocode Location"`.
  4. Verify that the geocoder returns dynamic coordinate outputs and displays `"Resolved: Lat: X, Lng: Y"`.
  5. Select a service (e.g., `Mechanic`) and verify that travel distances are recalculated relative to the new custom coordinate point.
- **Chat Location Refinement Test**:
  1. In the chat, type: `"main sector 4 airport society mein rehta hu"`.
  2. Verify that the parsing engine detects the location refinement, automatically updates the UI proximity badge, geocodes it, and ranks provider distances.
